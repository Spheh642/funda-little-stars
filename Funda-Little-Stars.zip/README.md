# Funda Little Stars

This ZIP contains the source project for the deployed Funda Little Stars web app.

Important: the original cover image is stored in the AppDeploy deployment but its binary could not be exported into this ZIP from the current session.

Run `npm install` then `npm run dev`.
