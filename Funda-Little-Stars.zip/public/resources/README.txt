Place funda-little-stars-cover.png here for the original cover image.
